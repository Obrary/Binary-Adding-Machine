Product: Binary Adding Machine, October 2014

Designer: Zombie Cat, http://zombie-cat.org/

Support:  http://forums.obrary.com/category/designs/binary-adding-machine

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
The Binary Adding Machine is designed to be cut on a Laser Cutter from plywood or MDF.